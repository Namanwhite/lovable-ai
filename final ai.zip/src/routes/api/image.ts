import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { prompt } = (await request.json()) as { prompt: string };
        const key = process.env.STABILITY_API_KEY;
        if (!key) {
          return Response.json({ error: "Missing STABILITY_API_KEY" }, { status: 500 });
        }
        if (!prompt || prompt.trim().length === 0) {
          return Response.json({ error: "Prompt required" }, { status: 400 });
        }

        const form = new FormData();
        form.append("prompt", prompt);
        form.append("output_format", "png");
        form.append("aspect_ratio", "1:1");

        const res = await fetch(
          "https://api.stability.ai/v2beta/stable-image/generate/core",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${key}`,
              Accept: "image/*",
            },
            body: form,
          },
        );

        if (!res.ok) {
          const text = await res.text();
          return Response.json(
            { error: `Stability error: ${text}` },
            { status: res.status },
          );
        }

        const buf = await res.arrayBuffer();
        const base64 = Buffer.from(buf).toString("base64");
        return Response.json({ image: `data:image/png;base64,${base64}` });
      },
    },
  },
});
