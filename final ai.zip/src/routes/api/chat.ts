import { createFileRoute } from "@tanstack/react-router";

const SYSTEM_PROMPT = `You are Xhyvora AI, the ultimate digital companion — warm, kind, empathetic, and lightning-fast. You are "The Universal Guide": make complex science, math, and code feel like a friendly chat.

RULES:
- Adapt to the user: simple analogies for beginners, precise and technical for experts.
- Always maintain a lovable, positive tone. Never rude or robotic.
- For all math, use LaTeX with $...$ (inline) or $$...$$ (block). Show step-by-step logic.
- Use markdown: headings, lists, code blocks with language tags.
- Speak whatever language the user speaks. Match their tone.
- Be concise by default; expand when depth is asked.
- You are safe, private, and protective of the user.

You are Xhyvora AI. Be helpful, be fast, be smart, be lovable.`;

type ChatBody = {
  messages: Array<{ role: "user" | "assistant" | "system"; content: string }>;
  webSearch?: boolean;
};

async function tavilySearch(query: string): Promise<string> {
  const key = process.env.TAVILY_API_KEY;
  if (!key) return "";
  try {
    const res = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: key,
        query,
        search_depth: "advanced",
        max_results: 5,
        include_answer: true,
      }),
    });
    if (!res.ok) return "";
    const data = (await res.json()) as {
      answer?: string;
      results?: Array<{ title: string; url: string; content: string }>;
    };
    const parts: string[] = [];
    if (data.answer) parts.push(`Answer: ${data.answer}`);
    if (data.results?.length) {
      parts.push(
        data.results
          .map((r, i) => `[${i + 1}] ${r.title} (${r.url})\n${r.content}`)
          .join("\n\n"),
      );
    }
    return parts.join("\n\n");
  } catch {
    return "";
  }
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as ChatBody;
        const groqKey = process.env.GROQ_API_KEY;
        if (!groqKey) {
          return new Response(JSON.stringify({ error: "Missing GROQ_API_KEY" }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
          });
        }

        const messages = [...body.messages];
        const lastUser = [...messages].reverse().find((m) => m.role === "user");

        if (body.webSearch && lastUser) {
          const ctx = await tavilySearch(lastUser.content);
          if (ctx) {
            messages.unshift({
              role: "system",
              content: `Live web context for the user's question. Cite sources inline as [1], [2] when you use them.\n\n${ctx}`,
            });
          }
        }

        messages.unshift({ role: "system", content: SYSTEM_PROMPT });

        const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${groqKey}`,
          },
          body: JSON.stringify({
            model: "llama-3.3-70b-versatile",
            messages,
            temperature: 0.7,
            max_tokens: 2048,
          }),
        });

        if (!groqRes.ok) {
          const text = await groqRes.text();
          return new Response(
            JSON.stringify({ error: `Groq error: ${text}` }),
            { status: groqRes.status, headers: { "Content-Type": "application/json" } },
          );
        }

        const data = (await groqRes.json()) as {
          choices: Array<{ message: { content: string } }>;
        };
        const content = data.choices?.[0]?.message?.content ?? "";
        return Response.json({ content });
      },
    },
  },
});
