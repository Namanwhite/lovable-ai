import { createFileRoute } from "@tanstack/react-router";

// Analyze an image via Gemini. Expects { imageBase64, mimeType, prompt }.
export const Route = createFileRoute("/api/vision")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { imageBase64, mimeType, prompt } = (await request.json()) as {
          imageBase64: string;
          mimeType: string;
          prompt?: string;
        };
        const key = process.env.GEMINI_API_KEY;
        if (!key) {
          return Response.json({ error: "Missing GEMINI_API_KEY" }, { status: 500 });
        }

        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [
                {
                  parts: [
                    { text: prompt || "Describe this image in detail. Be warm and helpful." },
                    { inline_data: { mime_type: mimeType, data: imageBase64 } },
                  ],
                },
              ],
            }),
          },
        );

        if (!res.ok) {
          const text = await res.text();
          return Response.json(
            { error: `Gemini error: ${text}` },
            { status: res.status },
          );
        }

        const data = (await res.json()) as {
          candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        };
        const content =
          data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("\n") ?? "";
        return Response.json({ content });
      },
    },
  },
});
