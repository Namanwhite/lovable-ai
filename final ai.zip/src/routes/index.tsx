import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Sparkles, Send, Globe, ImagePlus, Wand2, Loader2, X } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Xhyvora AI — Your Lovable Universal Guide" },
      {
        name: "description",
        content:
          "Xhyvora AI: a warm, lightning-fast companion for math, code, science, and everything in between. With live web search, image generation, and vision.",
      },
      { property: "og:title", content: "Xhyvora AI" },
      {
        property: "og:description",
        content: "Your lovable, universal AI guide. Fast, smart, and always kind.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Xhyvora,
});

type Msg = {
  role: "user" | "assistant";
  content: string;
  image?: string; // data URL for generated/uploaded image
};

function Xhyvora() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [webSearch, setWebSearch] = useState(false);
  const [attached, setAttached] = useState<{
    dataUrl: string;
    base64: string;
    mimeType: string;
  } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [loading]);

  async function handleFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const base64 = dataUrl.split(",")[1] ?? "";
      setAttached({ dataUrl, base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  }

  async function send() {
    const text = input.trim();
    if ((!text && !attached) || loading) return;

    setLoading(true);
    setInput("");

    // Image generation command: "/image <prompt>" or button flow uses generateImage()
    if (text.startsWith("/image ")) {
      const prompt = text.slice(7).trim();
      setMessages((m) => [...m, { role: "user", content: text }]);
      await generateImage(prompt);
      setLoading(false);
      return;
    }

    // Vision: image attached → send to Gemini
    if (attached) {
      const userMsg: Msg = {
        role: "user",
        content: text || "What's in this image?",
        image: attached.dataUrl,
      };
      setMessages((m) => [...m, userMsg]);
      const pendingImage = attached;
      setAttached(null);
      try {
        const res = await fetch("/api/vision", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            imageBase64: pendingImage.base64,
            mimeType: pendingImage.mimeType,
            prompt: text || undefined,
          }),
        });
        const data = await res.json();
        setMessages((m) => [
          ...m,
          { role: "assistant", content: data.content || data.error || "Hmm, nothing came back." },
        ]);
      } catch (e) {
        setMessages((m) => [
          ...m,
          { role: "assistant", content: `Sorry, vision failed: ${String(e)}` },
        ]);
      }
      setLoading(false);
      return;
    }

    // Normal chat
    const nextMessages: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextMessages.map((m) => ({ role: m.role, content: m.content })),
          webSearch,
        }),
      });
      const data = await res.json();
      setMessages((m) => [
        ...m,
        { role: "assistant", content: data.content || data.error || "…" },
      ]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: `Sorry — I hit a snag: ${String(e)}` },
      ]);
    }
    setLoading(false);
  }

  async function generateImage(prompt: string) {
    if (!prompt) return;
    setMessages((m) => [
      ...m,
      { role: "assistant", content: `✨ Generating: *${prompt}*` },
    ]);
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (data.image) {
        setMessages((m) => [
          ...m,
          { role: "assistant", content: `Here you go — hope you love it!`, image: data.image },
        ]);
      } else {
        setMessages((m) => [
          ...m,
          { role: "assistant", content: `Image generation failed: ${data.error}` },
        ]);
      }
    } catch (e) {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: `Image failed: ${String(e)}` },
      ]);
    }
  }

  async function triggerImageGen() {
    const prompt = input.trim();
    if (!prompt || loading) return;
    setInput("");
    setLoading(true);
    setMessages((m) => [...m, { role: "user", content: `/image ${prompt}` }]);
    await generateImage(prompt);
    setLoading(false);
  }

  const empty = messages.length === 0;

  return (
    <div className="flex flex-col h-screen max-h-screen">
      {/* Header */}
      <header className="flex items-center justify-between px-4 md:px-6 py-4 border-b border-border/50 backdrop-blur-md bg-background/40 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[image:var(--gradient-brand)] grid place-items-center glow-ring">
            <Sparkles className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold brand-text leading-none">Xhyvora AI</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Your Universal Guide</p>
          </div>
        </div>
        <div className="text-xs text-muted-foreground hidden sm:block">
          Powered by Groq · Tavily · Stability · Gemini
        </div>
      </header>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-6 space-y-6">
          {empty && (
            <div className="text-center py-16">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-[image:var(--gradient-brand)] grid place-items-center glow-ring mb-5">
                <Sparkles className="w-8 h-8 text-primary-foreground" />
              </div>
              <h2 className="text-3xl font-bold brand-text">Hello, friend.</h2>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                I'm Xhyvora — ask me anything. Math, code, science, life. I'll be warm, fast, and
                thorough.
              </p>
              <div className="grid sm:grid-cols-2 gap-2 mt-8 max-w-lg mx-auto text-left">
                {[
                  "Explain quantum entanglement like I'm 12",
                  "Solve $\\int x e^x dx$ step by step",
                  "/image a serene mountain lake at dawn",
                  "Give me a Python script for a Discord bot",
                ].map((s) => (
                  <button
                    key={s}
                    onClick={() => setInput(s)}
                    className="text-sm px-4 py-3 rounded-xl border border-border/60 bg-card/40 hover:bg-card/70 hover:border-primary/40 transition text-left"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <MessageBubble key={i} msg={m} />
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-[image:var(--gradient-brand)] grid place-items-center shrink-0">
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              </div>
              <div className="flex items-center gap-1.5 py-3">
                <span className="typing-dot w-2 h-2 rounded-full bg-primary" style={{ animationDelay: "0s" }} />
                <span className="typing-dot w-2 h-2 rounded-full bg-primary" style={{ animationDelay: "0.2s" }} />
                <span className="typing-dot w-2 h-2 rounded-full bg-primary" style={{ animationDelay: "0.4s" }} />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Composer */}
      <div className="border-t border-border/50 bg-background/60 backdrop-blur-md">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-4">
          {attached && (
            <div className="mb-2 flex items-center gap-2 p-2 rounded-lg bg-card/60 border border-border/60 w-fit">
              <img src={attached.dataUrl} alt="attached" className="w-12 h-12 object-cover rounded-md" />
              <span className="text-sm text-muted-foreground">Image attached</span>
              <button
                onClick={() => setAttached(null)}
                className="p-1 hover:bg-muted rounded-md"
                aria-label="Remove attachment"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
          <div className="flex items-end gap-2 p-2 rounded-2xl border border-border/60 bg-card/50 focus-within:border-primary/60 focus-within:glow-ring transition">
            <label className="p-2 hover:bg-muted rounded-lg cursor-pointer text-muted-foreground hover:text-foreground transition" title="Attach image (vision)">
              <ImagePlus className="w-5 h-5" />
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                  e.target.value = "";
                }}
              />
            </label>
            <button
              onClick={() => setWebSearch((v) => !v)}
              className={`p-2 rounded-lg transition ${
                webSearch
                  ? "bg-primary/20 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
              title="Toggle live web search"
            >
              <Globe className="w-5 h-5" />
            </button>
            <button
              onClick={triggerImageGen}
              disabled={loading || !input.trim()}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition disabled:opacity-40"
              title="Generate image from prompt"
            >
              <Wand2 className="w-5 h-5" />
            </button>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={1}
              placeholder={
                attached
                  ? "Ask about this image…"
                  : webSearch
                  ? "Ask anything — I'll search the web…"
                  : "Message Xhyvora…"
              }
              className="flex-1 bg-transparent resize-none outline-none py-2 px-1 max-h-40 text-[15px] placeholder:text-muted-foreground"
              style={{
                height: "auto",
                minHeight: "2.5rem",
              }}
              onInput={(e) => {
                const el = e.currentTarget;
                el.style.height = "auto";
                el.style.height = Math.min(el.scrollHeight, 160) + "px";
              }}
            />
            <button
              onClick={send}
              disabled={loading || (!input.trim() && !attached)}
              className="p-2.5 rounded-xl bg-[image:var(--gradient-brand)] text-primary-foreground hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition glow-ring"
              aria-label="Send"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </div>
          <p className="text-[11px] text-muted-foreground text-center mt-2">
            Tip: try <span className="text-foreground/80">/image sunset over Mars</span>, toggle 🌐 for web search, or attach an image for vision.
          </p>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`w-8 h-8 rounded-lg grid place-items-center shrink-0 ${
          isUser
            ? "bg-secondary text-foreground"
            : "bg-[image:var(--gradient-brand)] text-primary-foreground"
        }`}
      >
        {isUser ? "You" : <Sparkles className="w-4 h-4" />}
      </div>
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 ${
          isUser
            ? "bg-primary/15 border border-primary/30"
            : "bg-card/60 border border-border/60"
        }`}
      >
        {msg.image && (
          <img
            src={msg.image}
            alt=""
            className="rounded-xl mb-2 max-w-full max-h-96 object-contain"
          />
        )}
        {msg.content && (
          <div className="md text-[15px]">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}
